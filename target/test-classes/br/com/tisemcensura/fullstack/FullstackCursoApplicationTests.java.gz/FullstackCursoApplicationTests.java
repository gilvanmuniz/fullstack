package br.com.tisemcensura.fullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackCursoApplicationTests {

	@Test
	void contextLoads() {
	}

}
